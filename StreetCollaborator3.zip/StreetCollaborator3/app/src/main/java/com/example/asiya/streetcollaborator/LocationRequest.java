package com.example.asiya.streetcollaborator;

class LocationRequest {
    public void setFastestInterval(int i) {
    }
}
